Crunchyroll APK — extracted contents
======================================

This archive contains the files packaged inside the uploaded crunchyroll.apk:
- classes.dex / classes2.dex / classes3.dex: compiled Android Dalvik bytecode (NOT Java source)
- AndroidManifest.xml and res/: Android compiled/binary manifest and resources
- assets/ and lib/: packaged assets and native libraries

Important:
This is an extraction, not a Java/Kotlin source-code decompilation. JADX or APKTool is needed
to turn compiled bytecode/resources into readable decompiled output. The current environment
did not have JADX or APKTool available, and could not download them.

To generate readable decompiled source on Windows:
1. Download JADX from https://github.com/skylot/jadx/releases
2. Extract the ZIP and run jadx-gui.bat.
3. Open crunchyroll.apk, then use File > Save all (or the equivalent export option).
   For command line, run: jadx -d output crunchyroll.apk

Only inspect or modify apps you are authorized to analyze. Decompilation will not recover the
original project perfectly; names/comments may be missing and some code may be obfuscated.
